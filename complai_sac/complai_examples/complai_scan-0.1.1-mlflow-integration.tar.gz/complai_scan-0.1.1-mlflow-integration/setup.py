import setuptools

setuptools.setup(
    name='complai_scan',
    version='0.1.1-mlflow_integration',
    author='SKP',
    description='CLI for complai offline jobs',
    packages=setuptools.find_packages(),
    install_requires=['setuptools', 'xgboost==0.90', "pandas==1.3.2", "numpy==1.21.2", "scikit-learn==0.22.2","fsspec==2022.3.0",
                      'shap==0.39.0', 'NICEx==0.1.0', "dask[distributed]==2.3.0", "tinydb==4.4.0","tensorflow==2.2.0"],
    python_requires='>=3.5',
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: NA",
        "Operating System :: OS Independent",
    ], zip_safe=False
)
