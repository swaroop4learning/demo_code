import pickle
import logging
import numpy as np
import pandas as pd
import scipy
import sklearn
from timeit import default_timer as timer
from utils.get_connections import tiny_db_connection
from utils.shap_common_functions import get_shap_values, explainer_create


class GenerateShapRegression():
    def __init__(self):
        logging.info("Started Regression Shap Generation")

    def get_shap_aggregated_values(self, shap_method="Mean", shap_df=None):
        if shap_method == "Mean":
            shap_values_df = shap_df.apply(lambda row: abs(row), axis=1)
            shap_fin_df = np.mean(shap_values_df, axis=0)
            shap_fin_df_dict = shap_fin_df.to_dict()
        elif shap_method == "Mean Squared":
            shap_values_df = shap_df.apply(lambda row: row ** 2, axis=1)
            shap_fin_df = np.mean(shap_values_df, axis=0)
            shap_fin_df_dict = shap_fin_df.to_dict()
        elif shap_method == "Median":
            shap_fin_df = np.median(shap_df, axis=0)
            shap_fin_df = pd.Series(shap_fin_df)
            shap_fin_df_dict = shap_fin_df.to_dict()

        return shap_fin_df_dict

    def get_live_shap_drift(self, live_data_new_moified, config, model, explainer, validation_shap_df):
        for data in live_data_new_moified:

            if config["model_type"] == "Pipeline":
                observations_live = model[config["pipeline_transformer"]].transform(data)
            else:
                observations_live = None

            if observations_live is not None:
                if isinstance(observations_live, scipy.sparse.csr.csr_matrix):
                    observations_live = observations_live.toarray()
                else:
                    pass
                shap_values_live = get_shap_values(explainer, observations_live)
            else:
                shap_values_live = get_shap_values(explainer, data.to_numpy())

            try:
                shap_live_df = pd.DataFrame(shap_values_live.tolist(), columns=config["feature_names"])
            except ValueError:
                shap_live_df = pd.DataFrame(shap_values_live.tolist())
            if config["shap_method"]:
                shap_fin_df_dict_live = self.get_shap_aggregated_values(shap_method=config["shap_method"],
                                                                        shap_df=shap_live_df)
            else:
                shap_fin_df_dict_live = self.get_shap_aggregated_values(shap_df=shap_live_df)
            live_shap = pd.Series(shap_fin_df_dict_live)
            live_shap_sorted = live_shap.sort_values(ascending=False).reset_index()
            live_shap_index = pd.Series(live_shap_sorted.index.values + 1)
            live_shap_df = pd.concat([live_shap_sorted, live_shap_index], axis=1)
            live_shap_df.columns = ["Column_Name", "live_shap_aggregated", "live_rank"]
            fin_df = validation_shap_df.merge(live_shap_df, on="Column_Name")
            fin_df['DCG'] = fin_df["validation_shap_aggregated"] / np.log2(fin_df["live_rank"] + 1)
            ndcg_score_day = fin_df['DCG'].sum() / fin_df['iDCG'].sum()
            drift_detected_day = True if ndcg_score_day < 0.9 else False
            fin_df["feature_drifted"] = np.where(fin_df["live_rank"] == fin_df["validation_rank"], 0, 1)
            fin_df["num_features_drifted"] = fin_df["feature_drifted"].sum()
            fin_df = fin_df.loc[:, ["Column_Name", "feature_drifted", "num_features_drifted"]]

            yield {"live_shap_df_day": shap_live_df.to_dict(orient='records'), "ndcg_score_day": ndcg_score_day,
                   "drift_detected": drift_detected_day, "drift_info": fin_df.to_dict(orient='records'),
                   "live_shap_df_aggregated": live_shap_df.to_dict(orient='records')}

    def run(self, validation_data_new_moified, x_train_data, live_data_new_moified, model, config=None):
        try:
            logging.getLogger().setLevel(logging.INFO)

            start_time = timer()

            db = tiny_db_connection(config["db_path"])

            if isinstance(model, sklearn.svm._classes.SVR):
                logging.info(
                    "SVR not supported due to shap Kernel Explainer run time limitations, defaulting Drift score to 1")
                shap_aggregated_collection = db.table(config["shap_aggregated_values_collection"])
                shap_aggregated_collection.update({'latest_record_ind': 'N'})
                shap_aggregated_collection.insert({
                    "ndcg_score_day": 1,
                    "drift_detected": False,
                    "Drift_score": 1.0,
                    "latest_record_ind": "Y"
                })
            else:

                explainer, observations = explainer_create(model=model, train_data=x_train_data,
                                                           feature_names=config["feature_names"],
                                                           validation_data=validation_data_new_moified,
                                                           model_type=config["model_type"],
                                                           pipeline_transformer=config["pipeline_transformer"],
                                                           pipeline_predictor=config["pipeline_predictor"])

                if observations is not None:
                    if isinstance(observations, scipy.sparse.csr.csr_matrix):
                        observations = observations.toarray()
                    else:
                        pass
                    shap_values = get_shap_values(explainer, observations)
                else:
                    shap_values = get_shap_values(explainer, validation_data_new_moified.to_numpy())

                try:
                    shap_df = pd.DataFrame(shap_values.tolist(), columns=config["feature_names"])
                except ValueError:
                    shap_df = pd.DataFrame(shap_values.tolist())

                if config["shap_method"]:
                    shap_fin_df_dict = self.get_shap_aggregated_values(shap_method=config["shap_method"],
                                                                       shap_df=shap_df)
                else:
                    shap_fin_df_dict = self.get_shap_aggregated_values(shap_df=shap_df)

                logging.info("Validation SHAP generation Time : " + str(round(timer() - start_time, 5)) + " sec")

                try:
                    with open(config["explainer_dump_path"], "wb") as explainer_path:
                        pickle.dump(explainer, explainer_path)
                except pickle.PicklingError:
                    pass

                validation_shap = pd.Series(shap_fin_df_dict)
                validation_shap_sorted = validation_shap.sort_values(ascending=False).reset_index()
                validation_shap_index = pd.Series(validation_shap_sorted.index.values + 1)
                validation_shap_df = pd.concat([validation_shap_sorted, validation_shap_index], axis=1)
                validation_shap_df.columns = ["Column_Name", "validation_shap_aggregated", "validation_rank"]
                validation_shap_df['iDCG'] = validation_shap_df["validation_shap_aggregated"] / np.log2(
                    validation_shap_df["validation_rank"] + 1)
                validation_shap_df.replace([np.inf, -np.inf], 0, inplace=True)

                shap_daily_list = list(
                    self.get_live_shap_drift(live_data_new_moified=live_data_new_moified, config=config, model=model,
                                             validation_shap_df=validation_shap_df, explainer=explainer))

                shap_live_df = pd.DataFrame(shap_daily_list)
                shap_generated_values_df = shap_live_df["live_shap_df_day"]
                shap_aggregated_live_df = shap_live_df.loc[:, ["live_shap_df_aggregated", "drift_info"]]

                shap_aggregated_df = shap_live_df.loc[:, ["ndcg_score_day", "drift_detected"]]
                shap_aggregated_df["Drift_score"] = np.min(shap_aggregated_df["ndcg_score_day"])

                logging.info("Drift Score generation Time : " + str(round(timer() - start_time, 5)) + " sec")
                start_time = timer()

                shap_generated_values_df = shap_generated_values_df.apply(pd.Series)

                shap_df["latest_record_ind"] = 'Y'
                shap_generated_values_df["latest_record_ind"] = 'Y'
                shap_aggregated_df["latest_record_ind"] = 'Y'
                shap_aggregated_live_df["latest_record_ind"] = 'Y'
                validation_shap_df["latest_record_ind"] = 'Y'
                shap_aggregated_collection = db.table(config["shap_aggregated_values_collection"])
                shap_aggregated_collection.update({'latest_record_ind': 'N'})
                shap_aggregated_collection.insert_multiple(shap_aggregated_df.to_dict(orient='records'))
                validation_shap_generated_collection = db.table(config["validation_shap_generated_values_collection"])
                validation_shap_generated_collection.update({'latest_record_ind': 'N'})
                validation_shap_generated_collection.insert_multiple(
                    shap_df.to_dict(orient='records'))
                validation_shap_aggregated_collection = db.table(config["validation_shap_aggregated_values_collection"])
                validation_shap_aggregated_collection.update({'latest_record_ind': 'N'})
                validation_shap_aggregated_collection.insert_multiple(
                    validation_shap_df.to_dict(orient='records'))
                live_shap_generated_collection = db.table(config["live_shap_generated_values_collection"])
                live_shap_generated_collection.update({'latest_record_ind': 'N'})
                live_shap_generated_collection.insert_multiple(
                    shap_generated_values_df.to_dict(orient='records'))
                live_shap_aggregated_collection = db.table(config["live_shap_aggregated_values_collection"])
                live_shap_aggregated_collection.update({'latest_record_ind': 'N'})
                live_shap_aggregated_collection.insert_multiple(
                    shap_aggregated_live_df.to_dict(orient='records'))
                logging.info("DB Insert Time : " + str(round(timer() - start_time, 5)) + " sec")
                logging.info("DB Insert Time : " + str(round(timer() - start_time, 5)) + " sec")

        except Exception as error_message:
            logging.error(str(error_message))
            raise error_message
