import shap
import pickle
import logging
import numpy as np
import pandas as pd
import scipy
import re
from timeit import default_timer as timer
from utils.get_connections import tiny_db_connection
from utils.shap_common_functions import get_shap_values, explainer_create


class GenerateShapMultilclass():
    def __init__(self):
        logging.info("Started Multiclass Shap Generation")

    def get_target_class_label(self, value=None, target_classes=None):
        for k, v in target_classes.items():
            if int(v) == int(value):
                class_label = k
                break

        return class_label

    def get_shap_values(self, explainer, data, config=None):
        '''
        Function to get complete shap values (Base, Expected, Data).
        Args:
            explainer (shap.explainer object): SHAP Explainer object for which shap values are to be generated.
                                               Typically obtained from explainer_create(model, train_data) function call.
            data (pandas dataframe): Dataset for which shap values are to be generated (usually validation data)
        Returns:
            shap_values (list of shap values): list of three shap values (base values), (expected values) and (data)
        '''
        try:
            shap_values = explainer.shap_values(data)
        except Exception:
            shap_values = explainer.shap_values(data, check_additivity=False)

        if isinstance(shap_values, list) and (config["model_type"] == "Tree"):
            shap_values = np.stack((shap_values), axis=-1)

        elif isinstance(shap_values, list):
            shap_values = np.stack((shap_values), axis=-1)
            # shap_values = shap_values[:, :, 0]
            # print(shap_values)

        return shap_values

    def get_shap_aggregated_values(self, shap_method="Mean", config=None, shap_df=None):

        shap_fin_df_dict = {}
        if shap_method == "Mean":
            for each in config["target_classes"].values():
                target_label = self.get_target_class_label(value=each,
                                                           target_classes=config["target_classes"])
                for i in range(0, len(config["feature_names"])):
                    shap_values_df = shap_df.apply(lambda row: abs(
                        row[i][each]), axis=1)

                    shap_fin_df_dict["shap_val_" + config["feature_names"][i] + "_target_" + target_label] = np.mean(
                        shap_values_df, axis=0)
        elif shap_method == "Mean Squared":
            for each in config["target_classes"].values():
                target_label = self.get_target_class_label(value=each,
                                                           target_classes=config["target_classes"])
                for i in range(0, len(config["feature_names"])):
                    shap_values_df = shap_df.apply(lambda row:
                                                   row[i][each] ** 2, axis=1)

                    shap_fin_df_dict["shap_val_" + config["feature_names"][i] + "_target_" + target_label] = np.mean(
                        shap_values_df, axis=0)
        elif shap_method == "Median":
            for each in config["target_classes"].values():
                target_label = self.get_target_class_label(value=each,
                                                           target_classes=config["target_classes"])
                for i in range(0, len(config["feature_names"])):
                    shap_values_df = shap_df.apply(lambda row:
                                                   row[i][each], axis=1)

                    shap_fin_df_dict["shap_val_" + config["feature_names"][i] + "_target_" + target_label] = np.median(
                        shap_values_df, axis=0)
        return shap_fin_df_dict

    def get_live_shap_drift(self, live_data_new_moified, config, model, explainer, validation_shap_dict,
                            ndcg_score=100.0):
        live_df_all = []
        fin_df_all = []
        target_ndcg_dict = {}
        for data in live_data_new_moified:

            if config["model_type"] == "Pipeline":
                observations_live = model[config["pipeline_transformer"]].transform(data)
            else:
                observations_live = None

            if observations_live is not None:
                if isinstance(observations_live, scipy.sparse.csr.csr_matrix):
                    observations_live = observations_live.toarray()
                else:
                    pass
                shap_values_live = self.get_shap_values(explainer, observations_live, config=config)
            else:
                shap_values_live = self.get_shap_values(explainer, data.to_numpy(), config=config)

            try:
                shap_live_df = pd.DataFrame(shap_values_live.tolist(), columns=config["feature_names"])
            except ValueError:
                shap_live_df = pd.DataFrame(shap_values_live.tolist())

            shap_live_df.fillna(0, inplace=True)

            if config["shap_method"]:
                shap_fin_df_dict_live = self.get_shap_aggregated_values(shap_method=config["shap_method"],
                                                                        config=config,
                                                                        shap_df=shap_live_df)
            else:
                shap_fin_df_dict_live = self.get_shap_aggregated_values(shap_df=shap_live_df, config=config)

            live_shap = pd.Series(shap_fin_df_dict_live).reset_index()
            live_shap["target"] = live_shap["index"].apply(lambda x: x.split("_")[-1])

            for target in config["target_classes"].keys():
                validation_df = validation_shap_dict[target]

                live_shap_sorted = live_shap[live_shap["target"] == target][["index", 0]].set_index(
                    ["index"]).sort_values(by=[0],
                                           ascending=False).reset_index()
                live_shap_index = pd.Series(live_shap_sorted.index.values + 1)
                live_df = pd.concat([live_shap_sorted, live_shap_index], axis=1)
                live_df.columns = ["Column_Name", "live_shap_aggregated", "live_rank"]

                live_df["target"] = target
                fin_df = validation_df.merge(live_df, on="Column_Name")
                fin_df['DCG'] = fin_df["validation_shap_aggregated"] / np.log(fin_df["live_rank"] + 1)
                target_ndcg_score = fin_df['DCG'].sum() / fin_df['iDCG'].sum()

                fin_df["feature_drifted"] = np.where(fin_df["live_rank"] == fin_df["validation_rank"], 0, 1)
                fin_df["num_features_drifted"] = fin_df["feature_drifted"].sum()
                fin_df = fin_df.loc[:, ["Column_Name", "feature_drifted", "num_features_drifted"]]

                live_df["Column_Name"] = live_df["Column_Name"].apply(
                    lambda x: re.search('shap_val_(.*)_target_(.*)', x).group(1))
                fin_df["Column_Name"] = fin_df["Column_Name"].apply(
                    lambda x: re.search('shap_val_(.*)_target_(.*)', x).group(1))
                fin_df["target"] = target
                live_df_all.append(live_df)
                fin_df_all.append(fin_df)
                target_ndcg_dict[target] = target_ndcg_score

            # drift_detected_day = True if ndcg_score < 0.9 else False

            live_df_fin = pd.concat(live_df_all, axis=0)
            fin_df_fin = pd.concat(fin_df_all, axis=0)

            yield {"live_shap_df_day": shap_live_df.to_dict(orient='records'), "ndcg_score_day": target_ndcg_dict,
                   "drift_info": fin_df_fin.to_dict(orient="records"),
                   "live_shap_df_aggregated": live_df_fin.to_dict(orient="records")}

    def run(self, validation_data_new_moified, x_train_data, live_data_new_moified, model, config=None):
        try:
            logging.getLogger().setLevel(logging.INFO)
            logging.info(config["feature_names"])
            start_time = timer()

            explainer, observations = explainer_create(model=model, train_data=x_train_data,
                                                       feature_names=config["feature_names"],
                                                       validation_data=validation_data_new_moified,
                                                       model_type=config["model_type"],
                                                       pipeline_transformer=config["pipeline_transformer"],
                                                       pipeline_predictor=config["pipeline_predictor"])

            if observations is not None:
                if isinstance(observations, scipy.sparse.csr.csr_matrix):
                    observations = observations.toarray()
                else:
                    pass
                shap_values = self.get_shap_values(explainer, observations, config=config)
            else:
                shap_values = self.get_shap_values(explainer, validation_data_new_moified.to_numpy(), config=config)

            try:
                shap_df = pd.DataFrame(shap_values.tolist(), columns=config["feature_names"])
            except ValueError:
                shap_df = pd.DataFrame(shap_values.tolist())

            if config["shap_method"]:
                shap_fin_df_dict = self.get_shap_aggregated_values(shap_method=config["shap_method"], config=config,
                                                                   shap_df=shap_df)
            else:
                shap_fin_df_dict = self.get_shap_aggregated_values(shap_df=shap_df, config=config)

            logging.info("Validation SHAP generation Time : " + str(round(timer() - start_time, 5)) + " sec")
            try:
                with open(config["explainer_dump_path"], "wb") as explainer_path:
                    pickle.dump(explainer, explainer_path)
            except pickle.PicklingError:
                pass
            start_time = timer()

            validation_shap = pd.Series(shap_fin_df_dict).reset_index()
            validation_shap["target"] = validation_shap["index"].apply(lambda x: x.split("_")[-1])

            validation_shap_dict = {}
            for target in config["target_classes"].keys():
                validation_shap_sorted = validation_shap[validation_shap["target"] == target][["index", 0]].set_index(
                    ["index"]).sort_values(by=[0],
                                           ascending=False).reset_index()

                validation_shap_index = pd.Series(validation_shap_sorted.index.values + 1)
                validation_df = pd.concat([validation_shap_sorted, validation_shap_index], axis=1)

                validation_df.columns = ["Column_Name", "validation_shap_aggregated", "validation_rank"]
                validation_df["target"] = target
                validation_df['iDCG'] = validation_df["validation_shap_aggregated"] / np.log2(
                    validation_df["validation_rank"] + 1)
                validation_df.replace([np.inf, -np.inf], 0, inplace=True)

                validation_shap_dict[target] = validation_df

            shap_daily_list = list(
                self.get_live_shap_drift(live_data_new_moified=live_data_new_moified, config=config, model=model,
                                         validation_shap_dict=validation_shap_dict, explainer=explainer))
            # live_shap_df_aggregated_list=[item["live_shap_df_aggregated"] for item in shap_daily_list]
            # drift_info_list=[item["drift_info"] for item in shap_daily_list]
            # [item.pop(key) for key in ["live_shap_df_aggregated","drift_info"] for item in shap_daily_list]

            shap_live_df = pd.DataFrame(shap_daily_list)
            shap_generated_values_df = shap_live_df["live_shap_df_day"]

            # live_shap_df_aggregated_df=pd.DataFrame(live_shap_df_aggregated_list).fillna("NA")
            # drift_info_df= pd.DataFrame(drift_info_list).fillna("NA")
            shap_aggregated_live_df = shap_live_df.loc[:, ["live_shap_df_aggregated", "drift_info"]]

            shap_aggregated_df = shap_live_df["ndcg_score_day"].apply(pd.Series)

            shap_aggregated_df["Drift_score_day"] = shap_aggregated_df.min(axis=1)
            shap_aggregated_df["Drift_score"] = np.min(shap_aggregated_df["Drift_score_day"])
            shap_aggregated_df["Drift_detected"] = np.where(shap_aggregated_df["Drift_score_day"] < 0.9, True, False)

            #
            validation_shap_fin = pd.concat(validation_shap_dict.values(), axis=0)
            validation_shap_fin["Column_Name"] = validation_shap_fin["Column_Name"].apply(
                lambda x: re.search('shap_val_(.*)_target_(.*)', x).group(1))

            logging.info("Drift Score generation Time : " + str(round(timer() - start_time, 5)) + " sec")
            start_time = timer()
            db = tiny_db_connection(config["db_path"])
            #
            shap_generated_values_df = shap_generated_values_df.apply(pd.Series)
            shap_aggregated_df["latest_record_ind"] = 'Y'
            shap_df["latest_record_ind"] = 'Y'
            shap_generated_values_df["latest_record_ind"] = 'Y'
            shap_aggregated_live_df["latest_record_ind"] = 'Y'
            validation_shap_fin["latest_record_ind"] = 'Y'
            #
            shap_aggregated_collection = db.table(config["shap_aggregated_values_collection"])
            shap_aggregated_collection.update({'latest_record_ind': 'N'})
            shap_aggregated_collection.insert_multiple(shap_aggregated_df.to_dict(orient='records'))
            validation_shap_generated_collection = db.table(config["validation_shap_generated_values_collection"])
            validation_shap_generated_collection.update({'latest_record_ind': 'N'})
            validation_shap_generated_collection.insert_multiple(
                shap_df.to_dict(orient='records'))
            validation_shap_aggregated_collection = db.table(config["validation_shap_aggregated_values_collection"])
            validation_shap_aggregated_collection.update({'latest_record_ind': 'N'})
            validation_shap_aggregated_collection.insert_multiple(
                validation_shap_fin.to_dict(orient='records'))
            live_shap_generated_collection = db.table(config["live_shap_generated_values_collection"])
            live_shap_generated_collection.update({'latest_record_ind': 'N'})
            live_shap_generated_collection.insert_multiple(
                shap_generated_values_df.to_dict(orient='records'))
            live_shap_aggregated_collection = db.table(config["live_shap_aggregated_values_collection"])
            live_shap_aggregated_collection.update({'latest_record_ind': 'N'})
            live_shap_aggregated_collection.insert_multiple(
                shap_aggregated_live_df.to_dict(orient='records'))
            logging.info("DB Insert Time : " + str(round(timer() - start_time, 5)) + " sec")
        except Exception as error_message:
            logging.error(str(error_message))
            raise error_message
