import logging

class GetData():

    def __init__(self):
        logging.info("In Dummy Get Data Constructor")

    def get_data(yaml_path=None):

        return [0]