import logging

class GetPredictions():
    def __init__(self):
        logging.info("In Dummy Prediction Constructor")

    def get_proba_scores(self):
        return [0]
