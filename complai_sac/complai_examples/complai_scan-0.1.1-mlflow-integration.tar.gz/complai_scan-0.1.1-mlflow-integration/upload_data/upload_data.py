# import pandas as pd
# import argparse
# import logging
# from utils.get_connections import db_connection,minio_connection

import numpy as np
import pandas as pd
#from sklearn.linear_model import LogisticRegression
import pickle

with open(r"C:\Users\AH00577\Spark_POC\complai_scan\examples\example_regression\data\live_data\Period_2_Data.pkl",
          "rb") as mdl:
    model = pickle.load(mdl)

print(model.columns)

# model.reset_index(drop=True, inplace=True)
# model.drop(columns=['index'],inplace=True)
# print(model.index)
#
#
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Titanic-Binary\titanic_train_new.pkl",
#           "wb") as dd:
#     pickle.dump(model,dd)
# #
# print(len(model1))
#
# a=pd.concat([model,model1]).drop_duplicates(keep=False)
# print(len(a))


#
# X= model.iloc[:,:-1]
# y= model.iloc[:,-1]
#
# lr=LogisticRegression()
#
# lr_model=lr.fit(X,y)
#
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Titanic-Binary\titanic_val_new.pkl",
#           "rb") as val:
#     val_data = pickle.load(val)
#
# print(lr_model.predict_proba(val_data.iloc[:,:-1]))
#
#
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Titanic-Binary\titanic_lr_model.dat",
#           "wb") as dd:
#     pickle.dump(lr_model,dd)

#lr_model




# model["Sex"] = np.where(model["Sex"] == "male", 0, 1)
# model["Fare"] = model["Fare"].astype("float")
# model["Pclass"] = model["Pclass"].astype("float")
# model["SibSp"] = model["SibSp"].astype("float")
# model["Parch"] = model["Parch"].astype("float")
# model.drop(columns=["Ticket", "Cabin","PassengerId"], inplace=True)
# model["Embarked"] = np.where(model["Embarked"] == "S", 0,
#                              np.where(model["Embarked"] == "Q", 1, np.where(model["Embarked"] == "C", 2, 3))
#                              )
# print(model)
# print(model.columns)
#
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Titanic-Binary\titanic_val_new.pkl",
#           "wb") as dd:
#     pickle.dump(model,dd)

# PassengerId     object
# Pclass          object
# Sex             object
# Age            float64
# SibSp           object
# Parch           object
# Ticket          object
# Fare            object
# Cabin           object
# Embarked        object
# target_pred      int64


# import re
#
# a='shap_val_col_name_target_ssss'
# b=re.search('shap_val_(.*)_target_(.*)',a)
# print(b.group(1))

# model["income"]=np.where(model["income"]=='<=50K',0,1)
#
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Adult-Binary\Train_Data_new.pkl",
#           "wb") as dd:
#     pickle.dump(model,dd)


# from pmlb import fetch_data
# from sklearn.model_selection import train_test_split
# from sklearn.ensemble import RandomForestClassifier
# from sklearn.compose import ColumnTransformer
# from sklearn.preprocessing import StandardScaler,OneHotEncoder
# from sklearn.pipeline import Pipeline
# from nice.explainers import NICE
# import pandas as pd
#
#
# adult = fetch_data('adult')
# X = adult.drop(columns=['education-num','fnlwgt','target','native-country'])
# y = adult.loc[:,'target']
# feature_names = list(X.columns)
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Adult-Binary\Val_Data.pkl",
#           "rb") as mdl:
#     data = pickle.load(mdl)
# print(data.dtypes)
#
# X=model.iloc[:,:-1]
# Y=model.iloc[:,-1]
# x_train,x_test,y_train,y_test= train_test_split(X,Y,test_size=0.25,stratify=Y,random_state=42)
# print(x_train)
# print(x_test)
# print(y_train)
# print(y_test)
#
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Titanic-Binary\titanic_train.pkl",
#           "wb") as xtr:
#     pickle.dump(model.iloc[:500,:],xtr)
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Titanic-Binary\titanic_val.pkl",
#           "wb") as xvl:
#     pickle.dump(model.iloc[501:,:],xvl)
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Titanic-Binary\titanic_train.pkl",
#           "wb") as xtr:
#     pickle.dump(x_train,xtr)
# with open(r"C:\Users\AH00577\Downloads\Data\Data\Titanic-Binary\titanic_train.pkl",
#           "wb") as xtr:
#     pickle.dump(x_train,xtr)


# print(model.columns)
# print(model.dtypes)
# print(model["class_att"].unique())

# def upload_validation_raw_data(input_df=None, collection=None):
#     input_dict = input_df.to_dict(orient='records')
#     collection.insert_many(input_dict)
#     logging.info("Validation Raw Data Uploaded")
#
#
# def upload_validation_preprocssed_data(input_df=None, collection=None):
#     input_dict = input_df.to_dict(orient='records')
#     collection.insert_many(input_dict)
#     logging.info("Validation Preprocessed Data Uploaded")
# def upload_yaml(yaml_path=None, botoclient=None, minio_path=None):
#     file_bytes = open(yaml_path, 'rb')
#     botoclient.put_object(Body=file_bytes, Bucket='anthemecp-sit', Key="test/compali.yml")
#     logging.info("YAML file uploaded")
#
#
#
#
# def run():
#     logging.getLogger().setLevel(logging.INFO)
#     parser = argparse.ArgumentParser()
#     parser.add_argument("--db_url", default="", type=str)
#     parser.add_argument("--database", default="", type=str)
#     parser.add_argument("--validation_raw_collection", default="", type=str)
#     parser.add_argument("--validation_preprocessed_collection", default="", type=str)
#     parser.add_argument("--validation_raw_path", default="", type=str)
#     parser.add_argument("--validation_processed_path", default="", type=str)
#     parser.add_argument("--minio_host",
#                         default="https://minio-cognitive-platform-sit.apps.ent-ocp4-np1-har.antmdc.internal.das",
#                         type=str)
#     parser.add_argument("--aws_access_key_id", default="BFF3DOXJ6684K4L5FQQK", type=str)
#     parser.add_argument("--aws_secret_access_key", default="kz8qvjdYciy4CVZotJOjOnB88VG8w44jUVQ6rqVP", type=str)
#     parser.add_argument("--region_name", default="us-east-1", type=str)
#     parser.add_argument("--yaml_path", default="./binary.yml", type=str)
#     args = parser.parse_args()
#     validation_raw_df = pd.read_csv(args.validation_raw_path)
#     validation_processed_df = pd.read_csv(args.validation_processed_path)
#
#     botoclient = minio_connection(endpoint_url=args.minio_host, aws_access_key_id=args.aws_access_key_id,
#                                   aws_secret_access_key=args.aws_secret_access_key, region_name=args.region_name)
#     upload_yaml(yaml_path=args.yaml_path, botoclient=botoclient)
#     client = db_connection(url=args.db_url)
#
#     if client:
#         try:
#             db = client[args.database]
#             validation_collection = db[args.validation_raw_collection]
#             upload_validation_preprocssed_data(input_df=validation_raw_df, collection=validation_collection)
#             validation_preprocessed_collection = db[args.validation_preprocessed_collection]
#             upload_validation_preprocssed_data(input_df=validation_processed_df,
#                                                collection=validation_preprocessed_collection)
#         except Exception as error_message:
#             logging.error(str(error_message))
#             raise error_message
#         finally:
#             client.close()
#             logging.info("DONE")
#
